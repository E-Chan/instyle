@extends('templates.default')

@section('content')

<div class="row">

    <div class="col-lg-6 col-lg-offset-3">
    
    </div>

    <div class="col-lg-3">
        @include('user.partials.userblock')
        <hr>
    </div>
</div>

@stop

