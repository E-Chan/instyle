<?php

namespace Instyle\Http\Controllers;

class TimelineController extends Controller
{
    public function index()
    {
        return view('timeline');
    }
}