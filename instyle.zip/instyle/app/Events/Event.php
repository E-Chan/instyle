<?php

namespace Instyle\Events;

abstract class Event
{
    //
}
