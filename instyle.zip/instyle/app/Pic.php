<?php

namespace Instyle;

use Illuminate\Database\Eloquent\Model;

class Pic extends Model
{
    //
}
