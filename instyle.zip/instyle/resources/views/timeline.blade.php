@extends('templates.default')

@section('content')
    <div class="row" id="timeline">
        <div class="col-md-3" id="padding">
        </div>
        <div class="col-md-6">
            <div class="row" id="newPost">
                <h1> new post </h1>
            </div>

            <div class="row" id="posts">
                <h1>Timeline</h1>

            </div>
        </div>
        <div class="col-md-3" id="padding">
        </div>


    </div>

@stop