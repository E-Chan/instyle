<nav class="navbar navbar-default" role="navigation">
    <div class="container">
        <div class="navbar-header">
            <a class="navbar-brand" href="<?php echo e(route('home')); ?>"><img height="170%" src="logo.png"></img></a>
        </div>
        <div class="collapse navbar-collapse">
           <?php if(Auth::check()): ?> 
                <ul class="nav navbar-nav">
                    <li><a href="#">Timeline</a></li>
                    <li><a href="#">Amigos</a></li>
                </ul>
                <form class="navbar-form navbar-left" role="search" action="<?php echo e(route('search.results')); ?>">
                    <div class="form-group">
                        <input type="text" name="query" class="form-control" placeholder="Find people">
                    </div>
                    <button type="submit" class="btn btn-default">Search</button>
                </form>
           <?php endif; ?> 
            <ul class="nav navbar-nav navbar-right">
               <?php if(Auth::check()): ?> 
                    <li><img vspace="5"height="40px" class="media-object" alt="<?php echo e(Auth::user()->getUsername()); ?>" src="<?php echo e(Auth::user()->getAvatarUrl()); ?>"></li>
                    <li><a href="<?php echo e(route('profile.index', ['username' => Auth::user()->username])); ?>"><?php echo e(Auth::user()->getUsername()); ?></a></li>
                    <li><a href="#">Editar perfil</a></li>
                    <li><a href="<?php echo e(route('auth.signout')); ?>">Cerrar Sesión</a></li>
               <?php else: ?> 
                    <li><a href="<?php echo e(route('auth.signup')); ?>">Registro</a></li>
                    <li><a href="<?php echo e(route('auth.signin')); ?>">Iniciar sesión</a></li>
               <?php endif; ?> 
            </ul>
        </div>
    </div>
</nav>
