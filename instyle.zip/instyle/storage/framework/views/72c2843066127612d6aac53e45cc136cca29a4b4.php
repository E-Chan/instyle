

<?php $__env->startSection('content'); ?>

<div class="row">

    <div class="col-lg-6 col-lg-offset-3">
    
    </div>

    <div class="col-lg-3">
        <?php echo $__env->make('user.partials.userblock', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <hr>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('templates.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>