

<?php $__env->startSection('content'); ?>
    <div class="row" id="timeline">
        <div class="col-md-3" id="padding">
        </div>
        <div class="col-md-6">
            <div class="row" id="newPost">
                <h1> new post </h1>
            </div>

            <div class="row" id="posts">
                <h1>Timeline</h1>

            </div>
        </div>
        <div class="col-md-3" id="padding">
        </div>


    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>