<div class="media">
    <a class="pull-left" href="<?php echo e(route('profile.index', ['username' => $user->username])); ?>">
        <img height="100px" class="media-object" alt="<?php echo e($user->getUsername()); ?>" src="<?php echo e($user->getAvatarUrl()); ?>">
    </a>
    <div class="media-body">
        <h4 class="media-heading"><a href="<?php echo e(route('profile.index', ['username' => $user->username])); ?>"><?php echo e($user->getUsername()); ?></a></h4>
        <?php if($user->location): ?><p><?php echo e($user->location); ?></p>
        <?php endif; ?>

        <?php if(Auth::user()->isNot($user)): ?>
            <?php if(Auth::user()->isFollowing($user)): ?>
                <a class="btn btn-danger btn-xs" href="#">
                <i class="fa fa-eye-slash"></i> Unfollow</a>
            <?php else: ?>
                <a class="btn btn-success btn-xs" href="#">
                <i class="fa fa-eye"></i> Follow</a>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>