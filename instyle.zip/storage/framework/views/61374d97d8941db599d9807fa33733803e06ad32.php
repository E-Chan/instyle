

<?php $__env->startSection('content'); ?>
    <h3>Resultados de la búsqueda:</h3>

    <div class="row">
        <div class="col-lg-4">
        </div>
        <div class="col-lg-4">
            
            <?php if(!$users->count()): ?>
                <h1>No se han encontrado resultados :<</h1>
            <?php else: ?>

            <?php foreach($users as $user): ?>
                <?php echo $__env->make('user/partials/userblock', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php endforeach; ?>


        </div>
        <div class="col-lg-4">
        </div>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>