![alt tag](/public/logo.png)

Instyle.social (Name may be subject to changes), is a webpage being developed by me as my final degree´s project.

## Tecnologies involded

I'll be using Laravel Framework wich includes pretty much all the needs that a social network may require such as bundles for sanatizing user inputs to avoid SQL injection, secure log in forms and others.
>The official Laravel local development environment. Powered by Vagrant, Homestead gets your entire team on the same page with the latest PHP, MySQL, Postgres, Redis, and more.

## To-Do
- [x] Plan a layout and mockup
- [x] Prepare the enviroment
- [x] Push my commits to GitHub
- [x] Start developing
- [x] Push a presentable landing page
- [x] Build the DB
- [x] Prepare a user registry and login
- [ ] Allow users to add other users as friends


